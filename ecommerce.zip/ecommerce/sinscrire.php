<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@500&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <title>Document</title>
</head>
<body  style="background-color:#9A616D">
  <section style="width:850px;height:600px;background-color:white;margin-left:350px;margin-top:60px;display:flex;">
    <div>
<img src="img1.webp" width=400px height=550px style="margin-top:25px;padding-left:25px" >
    </div>
    <div style="padding-left:30px;padding-top:25px;">
    <h3 style="margin-top:30px;margin-left:120px;font-family: 'Oswald', sans-serif;font-size:3em">  INSCRIPTION</h3>
    <form action="ex.php" method="post">
<input type="text" id="firstname" name="firstname" style="border:none;border-bottom:2px solid;margin-top:30px;width:330px;margin-left:20px" placeholder="Prenom"><span class="glyphicon glyphicon-user"></span></br>
<input type="text" id="lastname" name="lastname" style="border:none;border-bottom:2px solid;margin-top:40px;width:330px;margin-left:20px" placeholder="Nom" ><span class="glyphicon glyphicon-user"></span></br>
<input type="email" id="firstname" name="email" style="border:none;border-bottom:2px solid;margin-top:40px;width:330px;margin-left:20px" placeholder="Email" ><span class="glyphicon glyphicon-envelope"></span></br>
<input type="password" id="password" name="password" style="border:none;border-bottom:2px solid;margin-top:40px;width:330px;margin-left:20px" placeholder="Mot de passe" ><span class="glyphicon glyphicon-pencil"></span></br>
<input type="text" id="adresse" name="adresse" style="border:none;border-bottom:2px solid;margin-top:40px;width:330px;margin-left:20px" placeholder="Adresse" ><span class="glyphicon glyphicon-map-marker"></span></br>
<input type="text" id="tel" name="tel" style="border:none;border-bottom:2px solid;margin-top:40px;width:330px;margin-left:20px" placeholder="numero de téléphone" ><span class="glyphicon glyphicon-phone"></span></br>
<button style="width:180px;height:50px;background-color:black;color:whitesmoke;margin-top:50px;margin-left:100px;text-align:center;font-family: 'Roboto', sans-serif;font-size:1.5em">S'inscrire &ensp; &#10132;</button>
    </form>
    </div>
  </section>
</body>
</html>